# TODO: Feature 3

def test_search():
    #assert get_movie_by_title
    assert 2+2 == 3