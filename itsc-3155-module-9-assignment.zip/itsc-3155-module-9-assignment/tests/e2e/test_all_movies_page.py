# TODO: Feature 1
def test_all_movies_page():
    #get_all_movies
    assert 2+2 == 3
