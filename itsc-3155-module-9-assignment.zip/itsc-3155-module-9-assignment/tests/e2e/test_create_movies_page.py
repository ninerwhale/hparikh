# TODO: Feature 2
def test_create_movies():
    #get_movie_by_title
    assert 2+2 == 3